<?php
include "connection.php";
if(isset($_GET['deleteid']))
    $id = $_GET['deleteid'];

    $sql = "DELETE FROM `infos` where id=$id";
    $result = mysqli_query($connection, $sql);
    print_r( '<script type="text/js">
    alert("Note that you cannot undo this");
</script>');
    if($result){
        //echo "Delete Successfully";
       
        header("Location: admin.php");
    }else{
        die(mysqli_error($connection));
    }


?>

