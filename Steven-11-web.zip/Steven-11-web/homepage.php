
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Steven 11</title>
    <link rel="stylesheet" href="css/homepage.css">
</head>
<body>
    <header>
        <img src="images/logo.jpg" class="logo">
        <nav class="navbar">
            <a href="login.php" class="login">Login</a>
            <div class="dropdown-menu">
                <button class="dropdown-button">Menu</button>
                <div class="dropdown-content">
                    <a href="homepage.php">Home</a>
                    <a href="index.html">Car Rentals</a>
                    <a href="process.html">Process</a>
                 
                </div>
            </div>
        </nav>
    </header>
    <div class="main">
        <h1>Welcome To Steven 11</h1>
        <p>Rental Cars</p>
        <button class="click"><a href="index.html">Get Started →</a></button>
    </div>
</body>
</html>