<?php
session_start(); 

$email = $_POST['email'];
$password = $_POST['password'];

if($email == "admin_01@gmail.com" && $password == "admin12345"){
  header("Location: admin.php");
}
else{
    include "connection.php";
    $query = "SELECT * FROM infos WHERE email = '$email' AND passwords = '$password'";
    $result = $connection->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $emails = $row['email'];
        
        echo '<script>
        alert("Login Successfuly");
        </script>';

        $_SESSION['email'] = $emails;
       echo '<script>
        window.location.href = "homelog.php";
       
       </script>';
        exit();
        
    } else {
        echo '<script>alert("In-correct credentials");
            window.location.href = "login.html";
        
        </script>';
    }

    $connection->close();
}

?>
