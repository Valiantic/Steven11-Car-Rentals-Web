<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="css/admin.css">
    <style>
        h2{
            text-align: center;
        }
           
        form{
            display: absolute;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            padding: 0;
            background-color: #f1f1f1;
        }
        .buttons{
            margin: 50px;
        }
        .box1 {
            margin-top: 0;
            padding: 10px;
            background-color: #fff;
            border-radius: 5px;
        }
        
        .table {
            width: 100%;
            margin-top: 5px;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 8px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #f2f2f2;
            font-weight: bold;
            margin: 10px;
            text-align: center;
        }
        
        .btn {
            padding: 5px;
            text-decoration: none;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }
        
        .btn-primary {
            margin-left: 20px;
            background-color: #007bff;
        }
        
        .btn-danger {  
            background-color: #dc3545;
            
        }
        .btn-primary a {
           text-decoration: none;
           color: white;
        }

        .btn-danger a {  
           text-decoration: none;
           color: white; 
        }

        .btn-primary a:hover {
           color: blue;
        }
        .btn-danger a:hover {  
           color: blue;
        }
        .logout{
            color: gold;
            font-weight: 500;
            font-size: 1.1em;
            width: 110px;
            height: 40px;
            background: transparent;
            border: 3px solid rgba(54, 59, 9, 0.815);
            border-radius: 10px;
            font-family: 'Reem Kufi Fun', sans-serif;

        }

        .logout a{
            text-decoration: none;
            color: white;
        }
        .logout a:hover{
           color: blue;
        }
    </style>
</head>
<body>
    <header>
        <img src="images/logo.jpg" class="logo">
        <h1 style="color: white;">Welcome Admin!</h1>
        <button class="logout"><a href="login.php">Logout</a></button>
    </header>


    <div class="box1">
        <h2 >All Accounts</h2>
    </div>

    <form action="update.php" method="post">
    <table class="table table-hover table-bordered table-striped">
<thead>
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Password</th>
        <th>Update&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Delete</th>
    </tr>
</thead>
<tbody>
   
    <?php
    include "connection.php";
    $query = "select * from `infos`";

    $result = mysqli_query($connection, $query);

    if(!$result){
        die("query Failed".mysqli_error($connection));
    }
    else{
        while($row = mysqli_fetch_assoc($result)){
            $id = $row['id'];
            $username = $row['username'];
            $email = $row['email'];
            $password = $row['passwords'];
            echo '<tr>
            <td>'.$id.'</td>
            <td>'.$username.'</td>
            <td>'.$email.'</td>
            <td>'.$password.'</td>
             <td class="buttons">
             <button class="btn btn-primary" name="updates"><a href="update.php?updateid='.$id.'" class="text-light">Update</a></button>
             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             <button class="btn btn-danger"><a href="delete.php?deleteid='.$id.'" class="text-light">Delete</button>
             </td>
             <td></td>
        </tr>';
            
            
        }
    }
?>

</tbody>
   </table>
    </form>
   

</body>
</html>