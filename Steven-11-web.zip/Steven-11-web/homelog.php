<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rentals</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Righteous&family=Source+Code+Pro:ital,wght@1,600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Righteous&family=Source+Code+Pro:ital,wght@1,600&family=Wix+Madefor+Text:ital@1&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Reem+Kufi+Fun&family=Righteous&family=Source+Code+Pro:ital,wght@1,600&family=Wix+Madefor+Text:ital@1&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
    <header>
        <img src="images/logo.jpg" class="logo">
        <nav class="navbar">
            
            <a href="logout.php" class="login">Log-out</a>
            <div class="dropdown-menu">
                <button class="dropdown-button">Menu</button>
                <div class="dropdown-content">
                    <a href="homelog.php">Home</a>
                    <a href="process.html">Process</a>
                </div>
            </div>
        </nav>
    </header>
    <div>
        <img class="bg" src="images/car.jpg">
        <h1>"Welcome back user!" <br><?php echo $_SESSION['email']?></h1>
    </div>
   <div>
    
   
   </div>
    <div class="company">
        <img src="images/page.jpg" class="pg">
        <section class="company-text">
            <p class="cttl">ABOUT US</p>
            <p class="ctxt">Why we chose car rentals as a web example of a transactional system? Well we chose it because of its practicality and it is easy to replicate
                mich like a normal site wiht basic features such as logging in, has a multifunction setting, minimalistic design and a straightforward landing page.
                Because of the flexibility and wide scope of ranges that we can place in our examples, you or the client can find all of everything you came for with just
                a few clicks. You can look for its price, car type, relative distance to the car's current place and your destination. Freedom and quality determines your place 
                once you rented at our rental franchise , for Steven11 - "Unlock Your Journey, One Rental at a Time!"
.
            </p>
        </section>
    </div>
    <div class="availablecars">
        <a class="title">Cars Available</a>
    <section class="textboxes">
        <div class="container">
            <div class="textimage"><img src="images/hondaccord2023.png"></div>
            <h2>Honda Accord 2023</h2>
            <a ><button><h4>Book Now!</h4><a href="checklist.html">Rental Rates: •M/T: ₱1,500 •A/T: ₱1,600</a></button></a>
        </div>
        <div class="container">
            <div class="textimage"><img src="images/mazda32018.png"></div>
            <h2>Mazda 3 2023</h2>
            <a ><button><h4>Book Now!</h4><a href="checklist.html">Rental Rates: •M/T: ₱900 •A/T:₱1,000</a></button></a>
        </div>
        <div class="container">
            <div class="textimage"><img src="images/geelyemgrand2023.png"></div>
            <h2>Geely Emgrand 2023</h2>
            <a ><button><h4>Book Now!</h4><a href="checklist.html">Rental Rates: •M/T: ₱1,400 •A/T: ₱1,500</a></button></a>
        </div>
        <div class="container">
            
            <div class="textimage"><img src="images/mitsubishimirageg42023.png"></div>
            <h2>Mitsubishi Mirage G4 2023</h2>
            <a ><button><h4>Book Now!</h4><a href="checklist.html">Rental Rates: •M/T: ₱1,100 •A/T: ₱1,300</a></button></a>
        </div>
        <div class="container">
            <div class="textimage"><img src="images/hondacivic2023.png"></div>
            <h2>Honda Civic 2023</h2>
            <a ><button><h4>Book Now!</h4><a href="checklist.html">Rental Rates: •M/T: ₱1,700 •A/T: ₱2,000</a></button></a>
        </div>
       </section>
    </div>
    <footer>
        <div class="footer-container">
            <ul>
            <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
            <li><a href="#"><i class="fa-brands fa-google"></i></a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <div class="line"><hr></div>
            <p>Copyright © 2023 <span>steven11.com</span> | All rights reserved</p>
        </div>
    </footer>
</body>
</html>