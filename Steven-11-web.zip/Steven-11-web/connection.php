<?php
    $servername = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "accounts";
    $connection = new mysqli($servername, $dbuser, $dbpass, $dbname); 
    if(!$connection){
        die("ERROR" . mysqli_error($connection));
    }
    
?>
