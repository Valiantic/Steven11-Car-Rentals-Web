


<?php 
     include "connection.php";
    $id = $_GET['updateid'];
    if(isset($_POST['submit'])){
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $sql = "UPDATE `infos` SET `username`='$username',`email`='$email',`passwords`='$password' WHERE id=$id";
        $result = mysqli_query($connection, $sql);
        if($result){

            echo '<script>
            
            
            alert("Update Successfuly");
            window.location.href= "admin.php";
            
            </script>';
        }
        else{
            die(mysqli_error($connection));
        }
    }
   
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        header {
            text-align: center;
            background-color: #333;
            color: #fff;
            padding: 20px;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .user-box {
            position: relative;
            margin-bottom: 20px;
        }

        .user-box input {
            width: 100%;
            padding: 10px 0;
            font-size: 16px;
            color: #333;
            border: none;
            border-bottom: 1px solid #888;
            outline: none;
            background: transparent;
        }

        .user-box label {
            position: absolute;
            top: 0;
            left: 0;
            font-size: 16px;
            color: #888;
            pointer-events: none;
            transition: 0.2s ease all;
        }

        .user-box input:focus ~ label,
        .user-box input:valid ~ label {
            top: -20px;
            font-size: 12px;
            color: #333;
        }

        button[type="submit"] {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 16px;
            font-weight: bold;
            color: #fff;
            background-color: #333;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.2s ease all;
        }

        button[type="submit"]:hover {
            background-color: #555;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #888;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>Update</h1>
    </header>
    <form method="post">
        <div class="user-box">
            <input required name="username" type="text">
            <label>Username</label>
        </div>
    <div class="user-box">
        <input required name="email" type="text">
        <label>Email</label>
    </div>
    <div class="user-box">
        <input required name="password" type="password">
        <label>Password</label>
    </div>
    <button type="submit" name="submit">UPDATE</button>
    <a href="admin.php">Return to admin page</a>
</body>
</html>



