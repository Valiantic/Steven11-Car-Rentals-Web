<?php
    if($_SERVER['REQUEST_METHOD']== 'POST'){
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
    }
    include "connection.php";

    if($connection){
        //echo "connecttion successfuly";
        $sql = "INSERT INTO `infos`(`username`, `email`, `passwords`) VALUES ('$username','$email','$password')";
        $result = mysqli_query($connection, $sql);
        if($result){
            echo '<script>
                alert("Data Inserted Successfully");
                window.location.href = "login.php";
            </script>';
            die(mysqli_error($connection));
        }
        else{
            die(mysqli_error($connection));
        }
    }
?>